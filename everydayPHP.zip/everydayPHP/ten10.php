<?php
for($i=0;$i<5;$i++)
{
    for($j=3;$j>=$i;$j--)
    {
        echo " ";
    }
    for($k=0;$k<=$i;$k++)
    {
        echo "* ";
    }
    echo "\n";
}
?>