<?php
for($i=0;$i<5;$i++)
{
    for($k=3;$k>=$i;$k--)
    {
        echo " $";
    }
  for($j=0;$j<=$i;$j++)
   {
      echo " *";
   }
   for($l=1;$l<=$i;$l++)
   {
       echo " *";
   }
   for($k=3;$k>=$i;$k--)
    {
        echo " $";
    }
   echo "<br>";
}

?>